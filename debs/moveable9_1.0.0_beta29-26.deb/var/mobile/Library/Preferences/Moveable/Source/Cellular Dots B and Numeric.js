(height, signalStrengthRaw, isTintBlack, extraOption, color)
{
	var lowerLimit = -130, upperLimit = -80;
	var range = Math.abs(lowerLimit - upperLimit);

	var percentage = 0;
	if (signalStrengthRaw <= lowerLimit) {
		percentage = 0;
	} else if (signalStrengthRaw >= upperLimit) {
		percentage = 100;
	} else {
		percentage = Math.round(100 * (signalStrengthRaw - lowerLimit) / range);
	}

	var
		canvas = document.createElement("canvas"),
		context = canvas.getContext("2d"),
		dotCount = 5,
		spacer = Math.round(height * 0.075),
		dotWidth = Math.floor(height * 0.275),
		dotHeight = dotWidth,
		lineWidth = 1,
		mainColor = "rgb(" + color.join() + ")",
		canvasHeight = height,
		canvasWidth = dotWidth * dotCount + 4 * spacer;

	canvas.width = canvasWidth * 3;
	canvas.height = canvasHeight;

	context.lineWidth = lineWidth;
	context.strokeStyle = mainColor;
	context.fillStyle = mainColor;

	percentPerDot = 100 / dotCount;
	radius = dotWidth / 2.0;
	cy = Math.round((height - dotWidth) / 2.0) + radius;
	radius = radius - lineWidth;

	for (var i = 0; i < dotCount; i++) {
		topLeft = i * spacer + i * dotWidth;
		cx = topLeft + dotWidth / 2.0;

		context.beginPath();
		context.arc(cx, cy, radius, 0, 2 * Math.PI);
		context.stroke();
		context.stroke();

		if (percentage > 20.0 * (i + 1))
			heightLocal = 1;
		else
			heightLocal = (percentage - 20.0 * i) / 20.0;

		if (percentage > ((i + 1) * percentPerDot)) {
			context.fill();
		} else if (percentage > (i * percentPerDot)) {
			fillWidth = 2 * radius * (percentage - (i * percentPerDot)) / percentPerDot;
			context.save();
			context.beginPath();
			context.arc(cx, cy, radius, 0, 2 * Math.PI, false);
			context.clip();
			context.fillRect(cx - radius, cy - radius, fillWidth, radius * 2);
			context.restore();
		}
	}

	var fontHeight = 0.45 * height;

	context.font = fontHeight + "pt -apple-system";
	context.textAlign = "left";
	context.textBaseline = "middle";
	context.fillText(-signalStrengthRaw, canvasWidth + 2 * spacer, height / 2);

	var
		croppedCanvas = document.createElement("canvas"),
		croppedContext = croppedCanvas.getContext("2d");

	croppedCanvas.width = canvasWidth + 2 * spacer + context.measureText(-signalStrengthRaw).width;
	croppedCanvas.height = canvasHeight;

	croppedContext.drawImage(canvas, 0, 0);

	return croppedCanvas.toDataURL("image/png");
}
